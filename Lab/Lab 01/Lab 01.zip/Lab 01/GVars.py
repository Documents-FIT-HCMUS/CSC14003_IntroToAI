#Global vars
G=None
pos=None
color_map=None